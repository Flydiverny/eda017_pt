package se.markusmaga.lth.pt.helper.menu;

public interface IMenuHandler {
	public void add(IMenuAction ma);
	public void showMenuAndExecuteAction();
}