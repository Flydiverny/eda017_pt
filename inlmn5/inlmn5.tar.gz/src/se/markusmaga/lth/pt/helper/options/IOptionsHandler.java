package se.markusmaga.lth.pt.helper.options;

public interface IOptionsHandler {
	//public boolean add(Option o);
	//public void changeOptions();
	//public Option getOption(String flag);
	//public boolean hasOption(String flag);
	//public boolean hasOptions();
}