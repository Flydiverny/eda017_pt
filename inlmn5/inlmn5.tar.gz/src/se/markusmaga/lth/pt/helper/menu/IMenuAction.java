package se.markusmaga.lth.pt.helper.menu;

public interface IMenuAction {
	public void execute();
	public String toString();
}