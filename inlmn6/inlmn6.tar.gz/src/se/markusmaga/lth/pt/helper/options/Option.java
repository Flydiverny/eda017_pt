package se.markusmaga.lth.pt.helper.options;

public class Option {
	private String key;
	private String desc;
	private int value;
	
	public Option(String key, String desc, int value) {
		this.key = key;
		this.desc = desc;
		this.value = value;
	}
	
	public String getDesc() {
		return this.desc;
	}
	
	public String getKey() {
		return key;
	}
	
	public void setValue(int value) {
		this.value = value;
	}
	
	public int getValue() {
		return value;
	}
}
