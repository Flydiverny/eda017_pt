package se.markusmaga.lth.pt.helper;

public interface IFunction {
	void execute();	// Code to execute.
}